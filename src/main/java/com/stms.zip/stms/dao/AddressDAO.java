package com.stms.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.stms.bean.Address;

public interface AddressDAO extends CrudRepository<Address, Long> {
//	List<Address> findByCity(String city);
}

