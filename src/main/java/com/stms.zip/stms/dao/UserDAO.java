package com.stms.dao;


import org.springframework.data.repository.CrudRepository;
import com.stms.bean.User;

public interface UserDAO extends CrudRepository<User, Long> {


	User findByEmailId(String emailId);
}

