package com.stms.dao;

import org.springframework.data.repository.CrudRepository;
import com.stms.bean.Orders;

public interface OrdersDAO extends CrudRepository<Orders, Long> {
}

