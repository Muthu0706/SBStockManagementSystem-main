package com.stms.dao;

import org.springframework.data.repository.CrudRepository;
import com.stms.bean.Product;

public interface ProductDAO extends CrudRepository<Product, Long> {
}
