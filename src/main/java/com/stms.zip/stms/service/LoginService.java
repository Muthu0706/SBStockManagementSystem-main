package com.stms.service;

import com.stms.bean.User;
import com.stms.dao.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    @Autowired
    private UserDAO userDAO;

    public User loginUser(String emailId, String password) {
        // Find the user by email
        User user = userDAO.findByEmailId(emailId);
        // If user exists and password matches, return the user
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null; // User not found or password incorrect
    }
}
