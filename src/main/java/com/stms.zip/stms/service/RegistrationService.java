package com.stms.service;

import com.stms.bean.User;
import com.stms.dao.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationService {

    @Autowired
    private UserDAO userDAO;

    public boolean registerUser(User user) {
        // Check if the user with the provided email already exists
        if (userDAO.findByEmailId(user.getEmailId()) != null) {
            return false; // User already exists
        }

        // Save the new user to the database
        userDAO.save(user);
        return true; // Registration successful
    }
}
